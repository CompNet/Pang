*   Note:    
    add #include <stdio.h> in brl_parser.cpp to get sprintf pass
    replace topology.c with 0.6 version of topology.c, update the corresponding igraph.h to support colored isomorphism

